from distutils.core import setup

setup(name ='bnWordnet',
version ='1.0pre1dev',
description ='Bengali Wordnet',
author ='Soumen Ganguly',
author_email ='soumendotganguly@gmail.com',
packages =['bnwordnet','bnwordnet.test'],
)
